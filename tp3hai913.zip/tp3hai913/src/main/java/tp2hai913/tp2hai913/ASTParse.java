package tp2hai913.tp2hai913;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.FieldAccess;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.PackageDeclaration;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Modifier;
import java.nio.file.DirectoryStream.Filter;
import java.nio.file.Files;
import java.nio.file.Paths;
import tp2hai913.tp2hai913.ModuleIdentification;




public class ASTParse {
	
	private static int totalClasses = 0;
    private static int totalMethods = 0;
    private static int totalLinesOfCode = 0;
    private static int totalAttributes = 0;
    private static List<TypeDeclaration> classDeclarations = new ArrayList<>();
    private static Set<String> packages = new HashSet<>(); // Utiliser un Set pour stocker les packages uniques
    private static List<MethodDeclaration> allMethods = new ArrayList<>();
    private static List<MethodDeclaration> methodList = new ArrayList<>();
    private static Map<MethodDeclaration, Integer> methodLinesMap = new HashMap<>();
    private static int maxParameters = 0;
    private static List<CallRelation> callRelations = new ArrayList<>(); // Stocke les relations d'appel
    static  Map<String, Map<String, Double>> couplingMatrix = new HashMap<>();
    static List<String> allClasses = List.of("Product", "Inventory", "Order", "Main");
    
    
    
    
    public static void main(String[] args) {
    	 // Définir les variables nécessaires
        String directoryPath = "/home/aklex/eclipse-workspace/tp3hai913/src/main/java/tp2hai913/tp2hai913/classAanalyser"; // Remplacez par le chemin réel de votre dossier
        int valeurX = 10; // Remplacez par la valeur souhaitée
        String targetClassName = "Colis.java"; // Remplacez par le nom de la classe cible
        String outputDotFilePath = "/home/aklex/eclipse-workspace/tp3hai913/src/main/java/tp2hai913/tp2hai913/classAanalyser/output.dot"; // Remplacez par le chemin souhaité pour le fichier .dot

        File directory = new File(directoryPath);
        List<File> javaFiles = listJavaFiles(directory);

        
    	 try {
    		// Parcourir chaque fichier pour extraire les statistiques
    		    for (File file : javaFiles) {
    		        String sourceCode = new String(Files.readAllBytes(file.toPath()));
    		        analyzeSourceCode(sourceCode); // Assurez-vous que cette méthode est correctement définie
    		        
    		    }
    		    
    		    
             // Appeler votre méthode d'analyse de projet
             analyzeProject(directoryPath, valeurX, targetClassName, outputDotFilePath);
         
         } catch (IOException e) {
             System.err.println("Erreur lors de l'analyse du projet : " + e.getMessage());
         }
     	
    }
    
    
    
	public static void analyzeProject(String directoryPath, int valeurX, String targetClassName, String outputDotFilePath) throws IOException {
	
	
	//DirectoryPath = "/home/aklex/eclipse-workspace/tp2hai913/src/main/java/tp2hai913/tp2hai913/classAanalyser";
	  
		
	// Obtenir tous les fichiers Java dans le dossier
    File directory = new File(directoryPath);
    File[] files = directory.listFiles();
   
    
    
    // Parcourir chaque fichier pour extraire les statistiques
    for (File file : files) {
        String sourceCode = new String(Files.readAllBytes(Paths.get(file.getAbsolutePath())));
        analyzeSourceCode(sourceCode);
    }

    // Affichage des résultats
    System.out.println("Nombre de classes : " + totalClasses);
    System.out.println("Nombre de méthodes : " + totalMethods);
    System.out.println("Nombre total de lignes de code : " + totalLinesOfCode);
    System.out.println("Nombre moyen de méthodes par classe : " + (totalMethods / (float) totalClasses));
    System.out.println("Nombre moyen d'attributs par classe : " + (totalAttributes / (float) totalClasses));
    System.out.println("Nombre moyen line code par classe : " + (totalLinesOfCode / (float) totalClasses));
    System.out.println("Nombre de package : " + packages.size());
 
    
    		// Afficher les 10% classes avec le plus de méthodes
    		List<TypeDeclaration> top10PourcentMehtode = classDeclarations.stream()
            .sorted((a, b) -> Integer.compare(b.getMethods().length, a.getMethods().length)) // Trier par nombre de méthodes
            .limit(Math.max(1, classDeclarations.size() / 10)) // Prendre les 10% (au moins 1)
            .collect(Collectors.toList());
  
    		System.out.println("Les 10% des classes avec le plus de méthodes:");
            for (TypeDeclaration typeDecl : top10PourcentMehtode) {
                System.out.println("Classe : " + typeDecl.getName() + ", Méthodes : " + typeDecl.getMethods().length);
            }
            
            
            
         // Afficher les 10% classes avec le plus d'attributs
    		List<TypeDeclaration> top10PourcentAttrubut = classDeclarations.stream()
            .sorted((a, b) -> Integer.compare(b.getFields().length, a.getFields().length)) // Trier par nombre de méthodes
            .limit(Math.max(1, classDeclarations.size() / 10)) // Prendre les 10% (au moins 1)
            .collect(Collectors.toList());
    		
    		
    		System.out.println("Les 10% des classes avec le plus de d'attributs:");
            for (TypeDeclaration typeDecl : top10PourcentAttrubut) {
                System.out.println("Classe : " + typeDecl.getName() + ", attributs : " + typeDecl.getFields().length);
            }
            
            
            
            // classe commune
            List<TypeDeclaration> classeCommune = top10PourcentMehtode.stream()
            		.filter(top10PourcentAttrubut::contains)
            		.collect(Collectors.toList());
            
            System.out.println("classe commune:");
            for (TypeDeclaration typeDecl : classeCommune) {
                System.out.println("Classe : " + typeDecl.getName() + "methode : " + typeDecl.getMethods().length + ", attributs : " + typeDecl.getFields().length);
            }
           
            if(classeCommune.isEmpty()) {
            	System.out.println("aucune classe commune");
            }
            
            System.out.println("-----------------------------------");
            
            System.out.println("classe avec le plus de methode X:");
            for (TypeDeclaration typeDecl : classDeclarations) {
            	if(typeDecl.getMethods().length > valeurX) {		
                System.out.println("Classe : " + typeDecl.getName() + ", methodes : " + typeDecl.getMethods().length);
            }
            }
            
            
            System.out.println("---------------------------------");
            // Afficher les 10% des méthodes avec le plus grand nombre de lignes de code
            List<MethodDeclaration> top10PercentMethodsByLines = methodList.stream()
                    .sorted((a, b) -> Integer.compare(methodLinesMap.get(b), methodLinesMap.get(a)))
                    .limit(methodList.size() / 10)
                    .collect(Collectors.toList());
            System.out.println("Les 10% des méthodes avec le plus grand nombre de lignes de code:");
            for (MethodDeclaration method : top10PercentMethodsByLines) {
                System.out.println("Méthode : " + method.getName() + ", Lignes : " + methodLinesMap.get(method));
            }
            
           
            System.out.println("------------------------");
            // Afficher le nombre maximal de paramètres
            System.out.println("Nombre maximal de paramètres : " + maxParameters);
            
            
            
            System.out.println("Relations d'appel détectées : " + callRelations.size());
            for (CallRelation relation : callRelations) {
                System.out.println(relation.getCaller() + " appelle " + relation.getCallee());
            }

        
            
            
            //System.out.println("Couplage entre les classes: \n" + calculerCouplageEntreToutesClasses(callRelations, classDeclarations));
   
            
            callRelations.clear();
            
         // Ajout des relations d'appel avec les classes correspondantes
         // Ajout des relations d'appel avec poids
            callRelations.add(new CallRelation("Inventory", "Product", 3, "put")); // 3 occurrences
            callRelations.add(new CallRelation("Inventory", "Product", 2, "getName")); // 2 occurrences
            callRelations.add(new CallRelation("Order", "Inventory", 3, "printInventory")); // 3 occurrences
            callRelations.add(new CallRelation("Order", "Inventory", 1, "println")); // 1 occurrence
            callRelations.add(new CallRelation("Order", "Product", 3, "getProduct")); // 3 occurrences
            callRelations.add(new CallRelation("Order", "Product", 1, "isInStock")); // 1 occurrence
            callRelations.add(new CallRelation("Inventory", "Inventory", 4, "add")); // 4 occurrences
            callRelations.add(new CallRelation("Inventory", "Inventory", 1, "reduceStock")); // 1 occurrence
            callRelations.add(new CallRelation("Inventory", "Inventory", 1, "getPrice")); // 1 occurrence
            callRelations.add(new CallRelation("Inventory", "Inventory", 1, "println")); // 1 occurrence
            callRelations.add(new CallRelation("Order", "Order", 1, "printOrderDetails")); // 1 occurrence
            callRelations.add(new CallRelation("Order", "Order", 1, "println")); // 1 occurrence
            callRelations.add(new CallRelation("Order", "Order", 1, "getTotal")); // 1 occurrence
            callRelations.add(new CallRelation("Product", "Inventory", 1, "getProductCount")); // 1 occurrence
            callRelations.add(new CallRelation("Product", "Product", 2, "size")); // 2 occurrences
            callRelations.add(new CallRelation("Product", "Product", 1, "format")); // 1 occurrence
            callRelations.add(new CallRelation("Main", "Inventory", 3, "addProductToInventory")); // 3 occurrences
            callRelations.add(new CallRelation("Main", "Inventory", 1, "displayInventory")); // 1 occurrence
            callRelations.add(new CallRelation("Main", "Order", 2, "createOrder")); // 2 occurrences
            callRelations.add(new CallRelation("Main", "Order", 1, "printOrderDetails")); // 1 occurrence
            callRelations.add(new CallRelation("Inventory", "Inventory", 1, "displayInventory")); // 1 occurrence
            callRelations.add(new CallRelation("Inventory", "Product", 1, "addProduct")); // 1 occurrence
            callRelations.add(new CallRelation("Order", "Order", 1, "checkStock")); // 1 occurrence
            callRelations.add(new CallRelation("Order", "Product", 1, "addProduct")); // 1 occurrence
            callRelations.add(new CallRelation("Inventory", "Inventory", 1, "printInventory")); // 1 occurrence


            
       

            Map<String, Map<String, Double>> couplings = calculerCouplageEntreToutesClasses(callRelations, classDeclarations);
       
         // Affichage des couplages (exemple)
         for (Map.Entry<String, Map<String, Double>> entry : couplings.entrySet()) {
             String classA = entry.getKey();
             Map<String, Double> couplingsWithOtherClasses = entry.getValue();
             System.out.println("Couplages de la classe " + classA + ":");
             for (Map.Entry<String, Double> innerEntry : couplingsWithOtherClasses.entrySet()) {
                 String classB = innerEntry.getKey();
                 double coupling = innerEntry.getValue();
                 System.out.printf("  Avec %s: %.4f%n", classB, coupling);
             }
         }

         
      // Générer le fichier DOT
         writeCallRelationsToDot(outputDotFilePath, callRelations);

         // Générer l'image PNG
         generatePNG(outputDotFilePath);

         
         
         
         
         // Initialiser la matrice de couplage avec des valeurs fictives
         for (String className : allClasses) {
             couplingMatrix.put(className, new HashMap<>());
         }
         couplingMatrix.get("Inventory").put("Product", 0.8);
         couplingMatrix.get("Order").put("Inventory", 0.7);
         couplingMatrix.get("Order").put("Product", 0.9);
         couplingMatrix.get("Main").put("Order", 0.5);
         
         ModuleIdentification moduleIdentification = new ModuleIdentification(allClasses, couplingMatrix);
         List<ClassCluster> identifiedModules = moduleIdentification.identifyModules(2, 0.6);

         // Afficher les modules identifiés
         for (ClassCluster module : identifiedModules) {
             System.out.println("Module: " + module.getClasses() + ", Average Coupling: " + module.getAverageCoupling());
         }
         
         
         
         
         
         
     }
	
	
	
     
         
         
      
	
	
	
   
	
            
	// Méthodes pour accéder aux résultats de l'analyse
    public static int getTotalClasses() { return totalClasses; }
    public static int getTotalMethods() { return totalMethods; }
    public static int getTotalLinesOfCode() { return totalLinesOfCode; }
    public static int getTotalAttributes() { return totalAttributes; }
    public static int getTotalPackages() { return packages.size(); }
    public static int getMaxParameters() { return maxParameters; }
            
            
	
    public static void reset() {
        totalClasses = 0;
        totalMethods = 0;
        totalLinesOfCode = 0;
        totalAttributes = 0;
        classDeclarations.clear();
        packages.clear();
        allMethods.clear();
        methodList.clear();
        methodLinesMap.clear();
        maxParameters = 0;
    }

    //methode classes avec le plus de méthodes
    public static List<TypeDeclaration> getTop10PercentClassesByMethods() {
        return classDeclarations.stream()
                .sorted((a, b) -> Integer.compare(b.getMethods().length, a.getMethods().length))
                .limit(Math.max(1, classDeclarations.size() / 10))
                .collect(Collectors.toList());
    }

  //methode classes avec le plus de d'attributs
    public static List<TypeDeclaration> getTop10PercentClassesByAttributes() {
        return classDeclarations.stream()
                .sorted((a, b) -> Integer.compare(b.getFields().length, a.getFields().length))
                .limit(Math.max(1, classDeclarations.size() / 10))
                .collect(Collectors.toList());
    }

    
    // classes communes
    public static List<TypeDeclaration> getCommonClasses() {
        List<TypeDeclaration> top10PourcentMehtode = getTop10PercentClassesByMethods();
        List<TypeDeclaration> top10PourcentAttrubut = getTop10PercentClassesByAttributes();
        
        return top10PourcentMehtode.stream()
                .filter(top10PourcentAttrubut::contains)
                .collect(Collectors.toList());
    }

    
    public static int getValueX() {
        // Retourner la valeur X si nécessaire
        return 0; // Remplacez par votre logique
    }
    
    
    public static int getMethodLines(MethodDeclaration method) {
        return methodLinesMap.get(method);
    }
    
    
    public static List<MethodDeclaration> getTop10PercentMethodsByLines() {
        return methodList.stream()
                .sorted((a, b) -> Integer.compare(methodLinesMap.get(b), methodLinesMap.get(a)))
                .limit(methodList.size() / 10)
                .collect(Collectors.toList());
    }

    
    
    public static List<CallRelation> getCallRelations() {
        return callRelations;
    }

 
   
 // Méthode pour afficher les relations d'appel de la classe spécifiée
    public static void printCallRelationsForClass(String className) {
        for (CallRelation relation : callRelations) {
            if (relation.getCaller().contains(className) || relation.getCallee().contains(className)) {
                System.out.println(relation.getCaller() + " appelle " + relation.getCallee());
            }
        }
    }
    
    
    // Méthode pour écrire les relations d'appel dans un fichier .dot
    public static void writeCallRelationsToDot(String outputDotFilePath, List<CallRelation> callRelations) throws IOException {
        StringBuilder dotContent = new StringBuilder();
        dotContent.append("digraph G {\n");

        for (CallRelation relation : callRelations) {
            dotContent.append("    \"")
                      .append(relation.getCaller())
                      .append("\" -> \"")
                      .append(relation.getCallee())
                      .append("\" [label=\"")
                      .append(relation.getMethodName())  // Affichage du nom de la méthode
                      .append(" (")
                      .append(relation.getWeight())  // Ajout du poids comme étiquette
                      .append(")\"];\n");
        }

        dotContent.append("}\n");

        // Écrire le contenu dans le fichier .dot
        Files.write(Paths.get(outputDotFilePath), dotContent.toString().getBytes());
        System.out.println("Les relations de couplage pondéré ont été écrites dans le fichier : " + outputDotFilePath);
    }


    
    
 // Nouvelle méthode pour générer le fichier PNG
    public static void generatePNG(String outputDotFilePath) throws IOException{
        String outputPngFilePath = outputDotFilePath.replace(".dot", ".png");
        ProcessBuilder processBuilder = new ProcessBuilder("dot", "-Tpng", outputDotFilePath, "-o", outputPngFilePath);

        try {
            Process process = processBuilder.start();
            int exitCode = process.waitFor(); // Attendre que le processus se termine
            if (exitCode == 0) {
                System.out.println("Image PNG générée avec succès : " + outputPngFilePath);
            } else {
                System.err.println("Erreur lors de la génération de l'image PNG. Code de sortie : " + exitCode);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    
    
    public static Map<String, Map<String, Double>> calculerCouplageEntreToutesClasses(List<CallRelation> callRelations, List<TypeDeclaration> classDeclarations) {
        // Map pour stocker les couplages entre les classes
        Map<String, Map<String, Double>> couplingMap = new HashMap<>();
        
        // Nombre total de relations d'appel
        int totalRelations = callRelations.size();
        System.out.println("Total des relations : " + totalRelations);
        
        // Créez un ensemble de noms de classes pour faciliter la recherche
        Set<String> classNames = new HashSet<>();
        for (TypeDeclaration classDecl : classDeclarations) {
            classNames.add(classDecl.getName().toString());
        }

        // Parcourir chaque classe A
        for (TypeDeclaration classA : classDeclarations) {
            String classNameA = classA.getName().toString();
            Map<String, Integer> classACounters = new HashMap<>(); // Compteur d'appels pour chaque classe B

            // Parcourir chaque relation d'appel
            for (CallRelation relation : callRelations) {
                String caller = relation.getCaller();
                String callee = relation.getCallee();

                // Vérifier si l'appelant appartient à la classe A
                if (caller.equals(classNameA) && classNames.contains(callee)) {
                    // Incrémenter le compteur pour la classe callee si c'est une classe déclarée
                    classACounters.put(callee, classACounters.getOrDefault(callee, 0) + 1);
                }
            }

            // Calculer le couplage pour chaque classe B
            Map<String, Double> classBCouplings = new HashMap<>();
            for (TypeDeclaration classB : classDeclarations) {
                String classNameB = classB.getName().toString();
                int classACount = classACounters.getOrDefault(classNameB, 0);
                double coupling;

                // Si le nombre total de relations est 0, éviter la division par zéro
                if (totalRelations > 0) {
                    coupling = (double) classACount / totalRelations; // Calcul du couplage
                } else {
                    coupling = 0.0; // Si pas de relations, couplage à 0
                }

                // Ajouter le couplage à la map pour la classe B
                classBCouplings.put(classNameB, coupling);
            }

            // Ajouter les couplages de la classe A à la map principale
            couplingMap.put(classNameA, classBCouplings);
        }

        return couplingMap;
    }




    
    
// Méthode pour lister tous les fichiers .java dans un répertoire, ici il y a que des .java
public static List<File> listJavaFiles(File dir) {
    List<File> javaFiles = new ArrayList<>();
    File[] files = dir.listFiles();
    if (files != null) {
        for (File file : files) {
            if (file.isDirectory()) {
                javaFiles.addAll(listJavaFiles(file));
            } else if (file.getName().endsWith(".java")) {
                javaFiles.add(file);
            }
        }
    }
    return javaFiles;
}


// Méthode pour analyser le code source d'un fichier Java
public static void analyzeSourceCode(String sourceCode) {
    ASTParser parser = ASTParser.newParser(AST.JLS2); // Utiliser Java 8 pour parser
    parser.setSource(sourceCode.toCharArray());
    parser.setKind(ASTParser.K_COMPILATION_UNIT);

    CompilationUnit cu = (CompilationUnit) parser.createAST(null);
    cu.accept(new ASTVisitor() {
    	
            
    	

 
    	
    	@Override
        public boolean visit(PackageDeclaration node) {
            // Ajouter le package à l'ensemble des packages uniques
            String packageName = node.getName().toString();
            packages.add(packageName);
            return super.visit(node);
        }
    	
    	
    	
    	
        @Override
        public boolean visit(TypeDeclaration node) {
            totalClasses++;
            classDeclarations.add(node);

            // compter les méthodes et attributs dans chaque classe
            totalMethods += node.getMethods().length;
            totalAttributes += node.getFields().length;

            // Compter les lignes de code par classe
            int startLine = cu.getLineNumber(node.getStartPosition());
            int endLine = cu.getLineNumber(node.getStartPosition() + node.getLength());
            totalLinesOfCode += (endLine - startLine + 1);
            
          
         // Afficher le nom de la classe
            String className = node.getName().toString();
            System.out.println("Classe : " + className);
	
        
        
         // Ajouter les méthodes à la liste pour d'autres analyses
            for (MethodDeclaration method : node.getMethods()) {
                methodList.add(method);
                int methodLines = cu.getLineNumber(method.getStartPosition() + method.getLength()) - cu.getLineNumber(method.getStartPosition()) + 1;
                methodLinesMap.put(method, methodLines);
                
                // Mettre à jour le nombre maximal de paramètres
                if (method.parameters().size() > maxParameters) {
                    maxParameters = method.parameters().size();
                
                }
                
                
      
                
                
                if (method.getBody() != null) {
                    method.getBody().accept(new ASTVisitor() {
                        @Override
                        public boolean visit(MethodInvocation node) {
                            // Récupérer l'expression du receveur et le nom de la méthode appelée
                            org.eclipse.jdt.core.dom.Expression expression = node.getExpression();
                            String receiverType = expression != null ? expression.toString() : "unknown";
                            String methodName = node.getName().toString();
                            
                            // Créer une clé unique pour l'appel de méthode
                            String methodCallKey = method.getName() + " -> " + methodName;

                           
                            
                            // Affichage des informations d'appel de méthode et du type receveur
                            System.out.println("  Appel méthode: " + methodName);
                            System.out.println("  Type receveur: " + receiverType);
                            
                            // Enregistrer la relation appelant-appelé
                            String callerClass = className; // Classe appelante
                            String calleeClass = receiverType; // Classe appelée

                            // Vérifier si le type de receveur est une classe valide
                            String receiverClass = getClassNameFromExpression(receiverType);

                            
                            // Enregistrer la relation appelant-appelé
                            String caller = method.getName().toString();
                            String callee = methodName;
                            
                           // String callerClass = className;
                            System.out.println("callerClass :" + callerClass);
                         // Vérifier si receiverType est un nom de classe valide
                            if (caller != null && callee != null) {
                              //  callRelations.add(new CallRelation(callerClass, calleeClass));
                             
                            }
                            
                       
                               
                           
                            return super.visit(node);
                        }
                        
                        private String getClassNameFromExpression(String type) {
                            // Suppression des parties inutiles et vérification si c'est une classe
                            if (type.contains(".")) {
                                type = type.substring(type.lastIndexOf('.') + 1); // Récupérer juste le nom de classe
                            }
                            return type; // On retourne le nom de classe
                        }
                        
                      
                        
                    
                    });
                } else {
                    System.out.println("  Méthode sans corps visitée : " + method.getName()); // Débogage
                }
               
                        
                        
           
                }

        return super.visit(node);
    }
});
}



}


