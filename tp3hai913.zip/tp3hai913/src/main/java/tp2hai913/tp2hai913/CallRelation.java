package tp2hai913.tp2hai913;

public class CallRelation {
    private String caller;
    private String callee;
    private int weight;  
    private String methodName; 

    public CallRelation(String caller, String callee, int weight, String methodeName) {
        this.caller = caller;
        this.callee = callee;
        this.weight = weight;
        this.methodName = methodeName;
       
    }

    public String getCaller() {
        return caller;
    }

    public String getCallee() {
        return callee;
    }
    

    // Getter pour le poids (couplage)
    public int getWeight() {
        return weight;
    }
    
    public String getMethodName() { // Getter pour le nom de la méthode
        return methodName;
    }
    
    
    @Override
    public String toString() {
        return caller + " -> " + callee;
    }
}
