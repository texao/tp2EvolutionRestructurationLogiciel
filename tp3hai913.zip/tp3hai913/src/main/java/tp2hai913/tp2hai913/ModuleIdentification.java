package tp2hai913.tp2hai913;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;



public class ModuleIdentification {
    private List<String> allClasses; // liste de toutes les classes
    private Map<String, Map<String, Double>> couplingMatrix; // Matrice de couplage

    public ModuleIdentification(List<String> allClasses, Map<String, Map<String, Double>> couplingMatrix) {
        this.allClasses = allClasses;
        this.couplingMatrix = couplingMatrix;
    }

    public List<ClassCluster> identifyModules(int maxModules, double minAverageCoupling) {
        List<ClassCluster> clusters = new ArrayList<>();
        List<String> mergeLog = new ArrayList<>(); // pour enregistrer les regroupements

        // Étape 1: initialiser chaque classe comme un cluster
        for (String className : allClasses) {
            ClassCluster cluster = new ClassCluster();
            cluster.addClass(className);
            cluster.setAverageCoupling(0.0); // Initialiser à 0
            clusters.add(cluster);
        }

        // Étape 2: Fusionner les clusters jusqu'à atteindre la limite de modules
        while (clusters.size() > 1) {
            int[] maxCouplingPair = findMaxCouplingPair(clusters);
            if (maxCouplingPair[0] == -1) break; // Pas de paires à combiner

            ClassCluster cluster1 = clusters.get(maxCouplingPair[0]);
            ClassCluster cluster2 = clusters.get(maxCouplingPair[1]);

            
            cluster1.getClasses().addAll(cluster2.getClasses());
            mergeLog.add("Regroupement: " + cluster2.getClasses() + " dans " + cluster1.getClasses());
            clusters.remove(cluster2); // Retirer le cluster fusionné

            // Calculer le nouveau couplage moyen après fusion
            double newAverageCoupling = calculateAverageCoupling(cluster1);
            cluster1.setAverageCoupling(newAverageCoupling);
        }

        
        for (String log : mergeLog) {
            System.out.println(log);
        }

        // Étape 3 : Filtrer les clusters selon les conditions
        return filterClusters(clusters, maxModules, minAverageCoupling);
    }

    private List<ClassCluster> filterClusters(List<ClassCluster> clusters, int maxModules, double minAverageCoupling) {
        List<ClassCluster> filteredClusters = new ArrayList<>();

        
        for (ClassCluster cluster : clusters) {
            if (filteredClusters.size() < maxModules / 2 && cluster.getAverageCoupling() > minAverageCoupling) {
                filteredClusters.add(cluster);
            }
        }

        return filteredClusters;
    }

    private int[] findMaxCouplingPair(List<ClassCluster> clusters) {
        double maxCoupling = -1;
        int[] maxPair = {-1, -1};

        for (int i = 0; i < clusters.size(); i++) {
            for (int j = i + 1; j < clusters.size(); j++) {
                double coupling = calculateCouplingBetweenClusters(clusters.get(i), clusters.get(j));
                if (coupling > maxCoupling) {
                    maxCoupling = coupling;
                    maxPair[0] = i;
                    maxPair[1] = j;
                }
            }
        }

        return maxPair;
    }

    private double calculateCouplingBetweenClusters(ClassCluster cluster1, ClassCluster cluster2) {
        double totalCoupling = 0.0;
        int count = 0;

        for (String class1 : cluster1.getClasses()) {
            for (String class2 : cluster2.getClasses()) {
                if (couplingMatrix.containsKey(class1) && couplingMatrix.get(class1).containsKey(class2)) {
                    totalCoupling += couplingMatrix.get(class1).get(class2);
                    count++;
                }
            }
        }

        return count > 0 ? totalCoupling / count : 0.0;
    }

    private double calculateAverageCoupling(ClassCluster cluster) {
        double totalCoupling = 0.0;
        int count = 0;

        for (String class1 : cluster.getClasses()) {
            for (String class2 : cluster.getClasses()) {
                if (!class1.equals(class2) && couplingMatrix.containsKey(class1) && couplingMatrix.get(class1).containsKey(class2)) {
                    totalCoupling += couplingMatrix.get(class1).get(class2);
                    count++;
                }
            }
        }

        return count > 0 ? totalCoupling / count : 0.0;
    }
}


