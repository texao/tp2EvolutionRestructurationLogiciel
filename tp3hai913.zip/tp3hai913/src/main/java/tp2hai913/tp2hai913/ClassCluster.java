package tp2hai913.tp2hai913;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;

public class ClassCluster {
    private List<String> classes;
    private double averageCoupling;

    public ClassCluster() {
        this.classes = new ArrayList<>();
        this.averageCoupling = 0.0;
    }

    public void addClass(String className) {
        classes.add(className);
    }

    public List<String> getClasses() {
        return classes;
    }

    public double getAverageCoupling() {
        return averageCoupling;
    }

    public void setAverageCoupling(double averageCoupling) {
        this.averageCoupling = averageCoupling;
    }
}


