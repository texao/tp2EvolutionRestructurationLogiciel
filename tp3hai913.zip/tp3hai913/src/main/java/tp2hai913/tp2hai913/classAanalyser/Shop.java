package tp2hai913.tp2hai913.classAanalyser;

public class Shop {
    private Inventory inventory;

    public Shop() {
        inventory = new Inventory();
    }

    public void addProductToInventory(Product product) {
        inventory.addProduct(product);
    }

    public void createOrder(Order order) {
        String[] productNames = {"Product1", "Product2"};
        int[] quantities = {1, 2};

        for (int i = 0; i < productNames.length; i++) {
            if (inventory.checkStock(productNames[i], quantities[i])) {
                order.addProduct(inventory.getProduct(productNames[i]), quantities[i]);
            }
        }
    }

    public void displayInventory() {
        inventory.printInventory();
    }
}

