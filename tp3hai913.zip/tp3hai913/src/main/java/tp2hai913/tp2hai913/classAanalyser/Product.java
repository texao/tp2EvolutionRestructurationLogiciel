package tp2hai913.tp2hai913.classAanalyser;

public class Product {
    private String name;
    private double price;
    private int stock;

    public Product(String name, double price, int stock) {
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    public void reduceStock(int quantity) {
        this.stock -= quantity;
    }

    public boolean isInStock(int quantity) {
        return stock >= quantity;
    }
    
    // Nouvelle méthode pour obtenir la description du produit
    public String getDescription() {
        return String.format("%s - Price: %.2f, Stock: %d", name, price, stock);
    }
}
