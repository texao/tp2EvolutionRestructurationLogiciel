package tp2hai913.tp2hai913.classAanalyser;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<Product> products;
    private double total;

    public Order() {
        products = new ArrayList<>();
        total = 0.0;
    }

    public void addProduct(Product product, int quantity) {
        if (product.isInStock(quantity)) {
            products.add(product);
            product.reduceStock(quantity);
            total += product.getPrice() * quantity;
        } else {
            System.out.println("Not enough stock for " + product.getName());
        }
    }

    public double getTotal() {
        return total;
    }

    public void printOrderDetails() {
        System.out.println("Order Details:");
        for (Product product : products) {
            System.out.println("Product: " + product.getDescription());
        }
        System.out.println("Total: " + getTotal());
    }

    // Nouvelle méthode pour obtenir le nombre de produits dans la commande
    public int getProductCount() {
        return products.size();
    }
}

