package tp2hai913.tp2hai913.classAanalyser;

import java.util.HashMap;
import java.util.Map;

import java.util.HashMap;
import java.util.Map;

public class Inventory {
    private Map<String, Product> products;

    public Inventory() {
        products = new HashMap<>();
    }

    public void addProduct(Product product) {
        products.put(product.getName(), product);
    }

    public Product getProduct(String name) {
        return products.get(name);
    }

    public void printInventory() {
        System.out.println("Current Inventory:");
        for (Product product : products.values()) {
            System.out.println("Product: " + product.getDescription());
        }
    }
    
    // Nouvelle méthode pour vérifier les stocks
    public boolean checkStock(String productName, int quantity) {
        Product product = getProduct(productName);
        return product != null && product.isInStock(quantity);
    }
}
