package tp2hai913.tp2hai913.classAanalyser;

public class Main {
    public static void main(String[] args) {
        // Création d'une boutique
        Shop shop = new Shop();
        
        // Ajout de produits à l'inventaire
        Product product1 = new Product("Product1", 10.0, 5);
        Product product2 = new Product("Product2", 15.0, 3);
        shop.addProductToInventory(product1);
        shop.addProductToInventory(product2);
        
        // Affichage de l'inventaire
        shop.displayInventory();
        
        // Création d'une commande
        Order order = new Order();
        shop.createOrder(order);
        
        // Affichage des détails de la commande
        order.printOrderDetails();
        
        // Affichage de l'inventaire après commande
        shop.displayInventory();
    }
}


